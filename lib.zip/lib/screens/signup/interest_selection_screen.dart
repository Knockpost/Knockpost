import 'dart:io';
import 'package:flutter/material.dart';
import '../../utils/haptic_helper.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import '../home_screen.dart';
import '../login_screen.dart';

class InterestSelectionScreen extends StatefulWidget {
  final String email;
  final String username;
  final String password;
  final String fullName;
  final File? profileImage;
  final bool isGoogleSignup;

  const InterestSelectionScreen({
    super.key,
    required this.email,
    required this.username,
    required this.password,
    required this.fullName,
    this.profileImage,
    this.isGoogleSignup = false,
  });

  @override
  State<InterestSelectionScreen> createState() =>
      _InterestSelectionScreenState();
}

class _InterestSelectionScreenState extends State<InterestSelectionScreen> {
  bool isLoading = false;

  final Map<String, List<String>> interestMap = {
    "Culture": ["Cultural Commentary", "Subcultures", "Festival", "Pop Culture", "Social Issues"],
    "Technology": ["AI", "Startups", "Programming", "Cybersecurity", "Gadgets"],
    "Business": ["Finance", "Investing", "Economy", "Entrepreneurship", "Marketing"],
    "Science": ["Space", "Psychology", "Biology", "Physics", "Environment"],
    "Music": ["Indie", "Hip Hop", "Classical", "Pop", "Electronic"],
    "Sports": ["Football", "Cricket", "Basketball", "Tennis", "Fitness"],
    "Art": ["Illustration", "Painting", "Photography", "Design", "Street Art"],
    "Movies": ["Hollywood", "Bollywood", "Anime", "Documentary", "Thriller"],
    "Books": ["Fiction", "Non-fiction", "Self Help", "Fantasy", "Poetry"],
    "Lifestyle": ["Minimalism", "Travel", "Productivity", "Mindfulness", "Habits"],
    "Health": ["Nutrition", "Mental Health", "Workout", "Yoga", "Sleep"],
    "Food": ["Cooking", "Street Food", "Vegan", "Desserts", "Coffee"],
    "Politics": ["World Politics", "Indian Politics", "Policy", "Geopolitics", "Debates"],
    "Gaming": ["PC Gaming", "Console", "Esports", "Mobile Gaming", "Indie Games"],
    "Fashion": ["Streetwear", "Luxury", "Minimal", "Vintage", "Sneakers"],
  };

  final Set<String> selectedInterests = {};
  final Set<String> expandedCategories = {};

  Future<void> createAccount() async {
    if (selectedInterests.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select at least one interest")),
      );
      return;
    }

    try {
      String? profileImageUrl;
      String uid = "";

      // Check if we are already logged in (Google Signup) or if we need to create an account
      User? currentUser = FirebaseAuth.instance.currentUser;
      
      if (currentUser != null && currentUser.email == widget.email) {
        // We are already logged in (Google)
        uid = currentUser.uid;

        // Link with Email/Password so they can use the Login button too!
        try {
          AuthCredential credential = EmailAuthProvider.credential(
              email: widget.email, password: widget.password);
          await currentUser.linkWithCredential(credential);
        } catch (e) {
          debugPrint("Note: Account already linked or error: $e");
          // If already linked, or error, we still proceed to save the profile
        }
      } else {
        // Email/Password Signup - Create Auth User first
        UserCredential userCredential = await FirebaseAuth.instance
            .createUserWithEmailAndPassword(
                email: widget.email, password: widget.password);
        uid = userCredential.user!.uid;
      }

      // 2. Upload Image to Storage (if selected)
      if (widget.profileImage != null) {
        final ref = FirebaseStorage.instance
            .ref()
            .child('profile_images')
            .child('$uid.jpg');
        await ref.putFile(widget.profileImage!);
        profileImageUrl = await ref.getDownloadURL();
      }

      // 3. Save Profile to Firestore
      await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .set({
        'uid': uid,
        'email': widget.email,
        'username': widget.username,
        'fullName': widget.fullName,
        'profileImageUrl': profileImageUrl ?? "",
        'interests': selectedInterests.toList(),
        'createdAt': FieldValue.serverTimestamp(),
      });

      if (mounted) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => const HomeScreen()),
          (route) => false,
        );
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message ?? "Authentication failed")),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error: ${e.toString()}")),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  void goLogin() {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              const Text(
                "Choose your interests",
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                "Select topics to personalize your experience.",
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.black54,
                ),
              ),
              const SizedBox(height: 30),
              Expanded(
                child: SingleChildScrollView(
                  child: Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: buildInterestChips(),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: isLoading ? null : () { KnockHaptics.tap(); createAccount(); },
                child: Container(
                  height: 58,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Center(
                    child: isLoading
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : const Text(
                            "Continue",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 17,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                  ),
                ),
              ),
              const SizedBox(height: 22),
              Center(
                child: GestureDetector(
                  onTap: () { KnockHaptics.tap(); goLogin(); },
                  child: const Text(
                    "Already have an account? Log in",
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.black54,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> buildInterestChips() {
    List<Widget> widgets = [];
    interestMap.forEach((category, subList) {
      widgets.add(buildChip(category, isMain: true));
      if (expandedCategories.contains(category)) {
        for (var sub in subList) {
          widgets.add(buildChip(sub, isMain: false));
        }
      }
    });
    return widgets;
  }

  Widget buildChip(String label, {required bool isMain}) {
    bool isSelected = selectedInterests.contains(label);
    return GestureDetector(
      onTap: () {
        KnockHaptics.selection();
        setState(() {
          if (isMain) {
            if (expandedCategories.contains(label)) {
              expandedCategories.remove(label);
            } else {
              expandedCategories.add(label);
            }
          } else {
            if (isSelected) {
              selectedInterests.remove(label);
            } else {
              selectedInterests.add(label);
            }
          }
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 12,
        ),
        decoration: BoxDecoration(
          color: isSelected || expandedCategories.contains(label)
              ? Colors.black
              : const Color(0xFFF2F2F2),
          borderRadius: BorderRadius.circular(30),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: isSelected || expandedCategories.contains(label)
                ? Colors.white
                : Colors.black,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}
